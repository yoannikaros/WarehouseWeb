<form method="POST" action="simpan-barang.php">

			<div class="form-group">
        <label>Nama:</label>
        <input type="text" name="product_name" class="form-control" placeholder="Masukan nama lengkap" />
        </div>
        <label>harga:</label>
        <input type="text" name="product_price" class="form-control" placeholder="Masukan nama lengkap" />
        </div>
        <label>qty:</label>
        <input type="text" name="product_qty" class="form-control" placeholder="Masukan nama lengkap" />
        </div>
        <div class="form-group">
        <label>gambar:</label>
        <input type="text" name="product_image" class="form-control" placeholder="Masukan alamat" /> 
		</div>
        <div class="form-group">
        <label>code:</label>
        <input type="text" name="product_code" class="form-control" placeholder="Masukan alamat" /> 
		</div>
			<button type="submit" name="submit" class="btn btn-primary">Checkout Sekarang</button>
		
			</form>